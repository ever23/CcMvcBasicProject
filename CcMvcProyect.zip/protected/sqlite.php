<?php

return [
    'class' => '\\Cc\\Mvc\\SQLite3',
    'param' => [dirname(__FILE__) . '/testdb.db', dirname(__FILE__) . '/testdb.sql']
];
