<?php

return [
    'class' => '\\Cc\\Mvc\\MySQLi',
    'param' => ['localhost', 'root', '', 'testDB']
];

