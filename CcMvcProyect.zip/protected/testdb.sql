

CREATE TABLE IF NOT EXISTS `test` (
  `id` int PRIMARY KEY,
  `campo1` varchar(10),
  `campo2` varchar(60),
  `campo3` date
  
) ;




insert into test values (1,'texto de prueva 1 campo1','texto de prueva 1 campo2','2016/13/11' );
insert into test values (2,'texto de prueva 2 campo1','texto de prueva 2 campo2','2016/13/12' );
insert into test values (3,'texto de prueva 2 campo1','texto de prueva 2 campo2','2016/13/12' );
